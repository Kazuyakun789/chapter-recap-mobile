# Chapter Recap Maker Mobile

Mobile-first Streamlit web app for extracting images from publicly accessible chapter URLs, uploading images from an Android phone, reviewing/reordering/removing images, stitching them vertically, and downloading PNG/ZIP results.

## Deploy free with Streamlit Community Cloud

1. Create or sign in to GitHub.
2. Create a new repository (for example `chapter-recap-mobile`). Upload `app.py`, `requirements.txt`, and `.streamlit/config.toml` (you may upload the README too).
3. Open https://share.streamlit.io/ and sign in with GitHub.
4. Choose **Create app**, select the repository and branch, and set the main file path to `app.py`.
5. Deploy. Once deployment finishes, open the generated `*.streamlit.app` address on Android Chrome.

## Run locally for testing

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Limitations

- URL extraction reads image URLs available in the HTML and lazy-load attributes. Pages requiring JavaScript rendering, login, cookies, or anti-bot challenges may not work.
- Free hosted apps can sleep, have resource limits, and are not suitable for extremely large images or long-running jobs.
- This is a focused mobile image extraction/stitching app; it does not include the desktop app's OCR, translation, or video editor.
